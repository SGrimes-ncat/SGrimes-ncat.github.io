<?php
// search.php
?>
<html>
<head>
<title>Search HTML</title>
</head>

<BODY>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<blockquote>
  <p>
  <h2>Search Truck Information</h2>
  <form action="result.php" method=post>
    <table width="60%" border="0" cellpadding="5" cellspacing="20">
    <tr>
      <td width="115"><strong>Key Word :  </strong></td>
      <td><input name="keyword" type="text" size="50" maxlength="50" /></td>
    </tr>

    <tr>
      <td width="115">Seach in  </td>
      <td><input name="searchin" type="radio" value="truck_name" checked/>
        &nbsp;Truck Name </td>
    </tr>
    <tr>
      <td width="115">&nbsp;</td>
      <td><input name="searchin" type="radio" value="location" />
&nbsp;Location </td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="reset" name="Reset" value="Clear" />
        &nbsp;&nbsp;&nbsp;&nbsp;
        <input type="submit" name="Submit" value="Search" /></td>
    </tr>
  </table>
  </form>
   </p>
</blockquote>
</body>
</html>